﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VPLAssistPlus.Models
{
    public class Contact
    {
        public int Id { get; set; }            // unique
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string Group { get; set; }      // Family/Friends/Work/etc.

        public Contact()
        {
            Name = "";
            Phone = "";
            Email = "";
            Group = "";
        }

        public Contact(int id, string name, string phone, string email, string group)
        {
            Id = id;
            Name = name ?? "";
            Phone = phone ?? "";
            Email = email ?? "";
            Group = group ?? "";
        }

        public override string ToString()
        {
            return Id + " - " + Name;
        }
    }
}
