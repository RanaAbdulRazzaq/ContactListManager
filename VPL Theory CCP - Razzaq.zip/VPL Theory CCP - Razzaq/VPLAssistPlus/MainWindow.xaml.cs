﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using VPLAssistPlus.Data;
using VPLAssistPlus.Models;

namespace VPLAssistPlus
{
    public partial class MainWindow : Window
    {
        private readonly ContactRepository _repo;
        private ObservableCollection<Contact> _contacts = new ObservableCollection<Contact>();

        public MainWindow()
        {
            InitializeComponent();
            string filePath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "contacts.json");
            _repo = new ContactRepository(filePath);
        }

        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            cmbGroup.ItemsSource = new List<string> { "Family", "Friends", "Work", "School", "Other" };
            cmbGroup.SelectedIndex = 0;

            await LoadContactsAsync();
        }

        // MULTITHREADING: load on background thread
        private async Task LoadContactsAsync()
        {
            ToggleUI(false);
            lblStatus.Text = "Loading...";

            try
            {
                var loaded = await Task.Run(() => _repo.Load());
                _contacts = new ObservableCollection<Contact>(loaded);
                dgContacts.ItemsSource = _contacts;
                UpdateSummary();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to load: " + ex.Message);
            }
            finally
            {
                lblStatus.Text = "";
                ToggleUI(true);
            }
        }

        // MULTITHREADING: save on background thread
        private async Task SaveAsync()
        {
            try
            {
                await Task.Run(() => _repo.Save(_contacts.ToList()));
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to save: " + ex.Message);
            }
        }

        private void ToggleUI(bool enabled)
        {
            btnAdd.IsEnabled = enabled;
            btnUpdate.IsEnabled = enabled;
            btnDelete.IsEnabled = enabled;
            btnClear.IsEnabled = enabled;
            btnSearch.IsEnabled = enabled;
            btnReset.IsEnabled = enabled;
        }

        private bool TryGetInputs(out Contact c)
        {
            c = new Contact();

            if (!int.TryParse(txtId.Text.Trim(), out int id))
            {
                MessageBox.Show("Invalid ID. Enter a number.");
                return false;
            }

            string name = txtName.Text.Trim();
            if (string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Name cannot be empty.");
                return false;
            }

            string phone = txtPhone.Text.Trim();
            if (string.IsNullOrWhiteSpace(phone))
            {
                MessageBox.Show("Phone cannot be empty.");
                return false;
            }

            // simple phone validation (digits + optional +)
            if (!Regex.IsMatch(phone, @"^\+?\d{7,15}$"))
            {
                MessageBox.Show("Phone must be 7-15 digits (optional +). Example: +923001234567");
                return false;
            }

            string email = txtEmail.Text.Trim();
            if (!string.IsNullOrWhiteSpace(email))
            {
                // basic email check
                if (!Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
                {
                    MessageBox.Show("Invalid email format.");
                    return false;
                }
            }

            c.Id = id;
            c.Name = name;
            c.Phone = phone;
            c.Email = email;
            c.Group = cmbGroup.SelectedItem != null ? cmbGroup.SelectedItem.ToString() : "Other";

            return true;
        }

        private async void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (!TryGetInputs(out Contact c)) return;

            if (_contacts.Any(x => x.Id == c.Id))
            {
                MessageBox.Show("This Contact ID already exists.");
                return;
            }

            _contacts.Add(c);
            UpdateSummary();
            await SaveAsync();
            ClearInputs();
        }

        private async void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            if (dgContacts.SelectedItem == null)
            {
                MessageBox.Show("Select a contact to update.");
                return;
            }

            if (!TryGetInputs(out Contact updated)) return;

            Contact selected = (Contact)dgContacts.SelectedItem;

            // If ID changed, ensure uniqueness
            if (updated.Id != selected.Id && _contacts.Any(x => x.Id == updated.Id))
            {
                MessageBox.Show("New ID already exists.");
                return;
            }

            selected.Id = updated.Id;
            selected.Name = updated.Name;
            selected.Phone = updated.Phone;
            selected.Email = updated.Email;
            selected.Group = updated.Group;

            dgContacts.Items.Refresh();
            UpdateSummary();
            await SaveAsync();
        }

        private async void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (dgContacts.SelectedItem == null)
            {
                MessageBox.Show("Select a contact to delete.");
                return;
            }

            Contact selected = (Contact)dgContacts.SelectedItem;

            var result = MessageBox.Show("Delete " + selected.Name + "?",
                "Confirm", MessageBoxButton.YesNo, MessageBoxImage.Warning);

            if (result != MessageBoxResult.Yes) return;

            _contacts.Remove(selected);
            UpdateSummary();
            await SaveAsync();
            ClearInputs();
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            ClearInputs();
        }

        private void ClearInputs()
        {
            txtId.Text = "";
            txtName.Text = "";
            txtPhone.Text = "";
            txtEmail.Text = "";
            cmbGroup.SelectedIndex = 0;
        }

        private void DgContacts_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgContacts.SelectedItem == null) return;

            Contact c = (Contact)dgContacts.SelectedItem;
            txtId.Text = c.Id.ToString();
            txtName.Text = c.Name;
            txtPhone.Text = c.Phone;
            txtEmail.Text = c.Email;
            cmbGroup.SelectedItem = c.Group;
        }

        // MULTITHREADING: search on background thread
        private async void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            string term = txtSearch.Text.Trim().ToLower();
            if (string.IsNullOrWhiteSpace(term))
            {
                MessageBox.Show("Enter search text.");
                return;
            }

            ToggleUI(false);
            lblStatus.Text = "Searching...";

            try
            {
                var results = await Task.Run(() =>
                    _contacts.Where(c =>
                        c.Name.ToLower().Contains(term) ||
                        c.Phone.ToLower().Contains(term) ||
                        c.Email.ToLower().Contains(term) ||
                        c.Group.ToLower().Contains(term)
                    ).ToList()
                );

                dgContacts.ItemsSource = new ObservableCollection<Contact>(results);
                lblStatus.Text = "Found: " + results.Count;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Search failed: " + ex.Message);
            }
            finally
            {
                ToggleUI(true);
            }
        }

        private void BtnReset_Click(object sender, RoutedEventArgs e)
        {
            dgContacts.ItemsSource = _contacts;
            lblStatus.Text = "";
            UpdateSummary();
        }

        private void UpdateSummary()
        {
            lblTotal.Text = "Total Contacts: " + _contacts.Count;

            int groupCount = _contacts.Select(c => c.Group).Distinct().Count();
            lblGroupCount.Text = "Groups: " + groupCount;
        }
    }
}
