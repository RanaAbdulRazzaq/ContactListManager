﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using VPLAssistPlus.Models;

namespace VPLAssistPlus.Data
{
    public class ContactRepository
    {
        private readonly string _filePath;

        public ContactRepository(string filePath)
        {
            _filePath = filePath;
        }

        public List<Contact> Load()
        {
            try
            {
                if (!File.Exists(_filePath))
                    return new List<Contact>();

                string json = File.ReadAllText(_filePath);
                var data = JsonConvert.DeserializeObject<List<Contact>>(json);
                return data ?? new List<Contact>();
            }
            catch
            {
                return new List<Contact>();
            }
        }

        public void Save(List<Contact> contacts)
        {
            try
            {
                string json = JsonConvert.SerializeObject(contacts, Formatting.Indented);
                File.WriteAllText(_filePath, json);
            }
            catch (Exception ex)
            {
                throw new Exception("Could not save file: " + ex.Message);
            }
        }
    }
}
